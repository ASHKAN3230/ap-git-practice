#include "stack_calculator.h"

Stack *createStack()
{
    Stack *stack = (Stack *)malloc(sizeof(Stack));
    stack->top = -1;
    return stack;
}

void push(Stack *stack, int data)
{
    if (stack->top < MAX_SIZE - 1)
    {
        stack->array[++(stack->top)] = data;
    }
}

int pop(Stack *stack)
{
    if (stack->top >= 0)
    {
        return stack->array[(stack->top)--];
    }
    return -1;
}

int isOperator(char op)
{
    return op == '+' || op == '-' || op == '*' || op == '/';
}

int applyOperator(int a, int b, char op)
{
    switch (op)
    {
    case '+':
        return a + b;
    case '-':
        return a - b;
    case '*':
        return a * b;
    case '/':
        return a / b;
    }
    return 0;
}

int evaluateExpression(char *expression)
{
    Stack *stack = createStack();
    char *token = strtok(expression, " ");

    while (token != NULL)
    {
        if (isdigit(token[0]))
        {
            push(stack, atoi(token));
        }
        else if (isOperator(token[0]))
        {
            int b = pop(stack);
            int a = pop(stack);
            int result = applyOperator(a, b, token[0]);
            push(stack, result);
        }
        token = strtok(NULL, " ");
    }

    int finalResult = pop(stack);
    free(stack);
    return finalResult;
}