
#include "transform.h"

void printArray(const int *arr, unsigned int size)
{
    for (unsigned int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int *transform(const int *arr, unsigned int size, int (*callbackFunc)(int))
{
    int *newArr = (int *)malloc(size * sizeof(int));
    if (newArr == NULL)
    {
        printf("Memory allocation failed!\n");
        return NULL;
    }

    for (unsigned int i = 0; i < size; i++)
    {
        newArr[i] = callbackFunc(arr[i]);
    }

    return newArr;
}